Vivere rispettando i bisogni di tutti e del Pianeta.![[Pasted image 20230130123819.jpg]]
