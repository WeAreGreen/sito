[Domanda] Essere sostenibili significa anche interessarsi del futuro. [/Domanda]
[Risposta sbagliata] falso[/Risposta sbagliata]
[Risposta giusta]vero [/Risposta giusta]