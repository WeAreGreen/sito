Oggigiorno **il mondo è abbastanza lontano dall'essere considerato sostenibile** .![[Pasted image 20230130130437.jpg]]
