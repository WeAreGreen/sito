BUG (RISCONTRATI):
nessuno

IMPORTANTE:
    BACKGROUD:
        style="background-image:url('https://d1di2lzuh97fh2.cloudfront.net/files/39/398/3980y9.jpg?ph=36c077745e')"
